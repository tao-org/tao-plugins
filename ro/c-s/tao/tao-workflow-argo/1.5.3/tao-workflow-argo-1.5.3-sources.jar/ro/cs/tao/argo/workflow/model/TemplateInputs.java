package ro.cs.tao.argo.workflow.model;

import java.util.List;

public class TemplateInputs {
    private List<WorkflowArtifact> artifacts;
    private List<WorkflowParameter> parameters;

    public List<WorkflowArtifact> getArtifacts() {
        return artifacts;
    }

    public void setArtifacts(List<WorkflowArtifact> artifacts) {
        this.artifacts = artifacts;
    }

    public List<WorkflowParameter> getParameters() {
        return parameters;
    }

    public void setParameters(List<WorkflowParameter> parameters) {
        this.parameters = parameters;
    }
}
