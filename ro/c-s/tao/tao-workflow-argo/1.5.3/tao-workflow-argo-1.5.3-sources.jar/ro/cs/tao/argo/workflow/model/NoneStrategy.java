package ro.cs.tao.argo.workflow.model;

public class NoneStrategy{

}
