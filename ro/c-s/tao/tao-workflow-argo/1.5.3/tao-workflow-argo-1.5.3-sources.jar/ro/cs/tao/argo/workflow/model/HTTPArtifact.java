package ro.cs.tao.argo.workflow.model;

public class HTTPArtifact {
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
