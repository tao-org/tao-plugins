package ro.cs.tao.topology.openstack.commons;

/**
 * The Constants class contains a collection of constant string keys used for configuring
 * and interacting with the OpenStack platform.
 *
 * These configuration keys include credentials, endpoints, regions, network settings,
 * volume types, flavors, and other platform-specific settings. The class provides
 * centralized and reusable definitions for commonly used constants to avoid hardcoding
 * throughout the application.
 *
 * The class is designed to be used as a utility and does not require instantiation.
 */
public class Constants {
    public static final String OPENSTACK_USER = "openstack.user";
    public static final String OPENSTACK_PASSWORD = "openstack.password";
    public static final String OPENSTACK_AUTH_URL = "openstack.auth.url";
    public static final String OPENSTACK_REGION = "openstack.region";
    public static final String OPENSTACK_DOMAIN = "openstack.domain";
    public static final String OPENSTACK_TENANT_ID = "openstack.tenantId";
    public static final String OPENSTACK_BUCKET = "openstack.bucket";
    public static final String OPENSTACK_TOKEN_URL = "openstack.token.url";
    public static final String OPENSTACK_IDENTITY_PROVIDER = "openstack.identity.provider";
    public static final String OPENSTACK_CLIENT = "openstack.client";
    public static final String OPENSTACK_CLIENT_SECRET = "openstack.client.secret";
    public static final String OPENSTACK_USER_SECRET = "openstack.user.secret";
    public static final String OPENSTACK_DEFAULT_SECURITY_GROUP = "openstack.default.security.group";
    public static final String OPENSTACK_FLOATING_IP_POOL = "openstack.floating.ip.pool";
    public static final String OPENSTACK_VOLUME_TYPE_SSD = "openstack.volume.type.ssd";
    public static final String OPENSTACK_VOLUME_SSD_SIZE = "openstack.volume.ssd.size";
    public static final String OPENSTACK_VOLUME_SSD_DEVICE = "openstack.volume.ssd.device";
    public static final String OPENSTACK_VOLUME_TYPE_HDD = "openstack.volume.type.hdd";
    public static final String OPENSTACK_VOLUME_HDD_SIZE = "openstack.volume.hdd.size";
    public static final String OPENSTACK_VOLUME_HDD_DEVICE = "openstack.volume.hdd.device";
    public static final String OPENSTACK_PRIVATE_NETWORK = "openstack.private.network";
    public static final String OPENSTACK_DATA_NETWORK = "openstack.eodata.network";
    public static final String OPENSTACK_OS_IMAGE = "openstack.default.image";
    public static final String OPENSTACK_DEFAULT_FLAVOUR = "openstack.default.flavour";
    public static final String OPENSTACK_PAGE_LIMIT = "page.limit";
    public static final String OPENSTACK_SWIFT_FILTER = "openstack.swift.";
    public static final String OPENSTACK_SWIFT_USER = OPENSTACK_SWIFT_FILTER + "user";
    public static final String OPENSTACK_SWIFT_PASSWORD = OPENSTACK_SWIFT_FILTER + "password";
    public static final String OPENSTACK_SWIFT_AUTH_URL = OPENSTACK_SWIFT_FILTER + "auth.url";
    public static final String OPENSTACK_SWIFT_REGION = OPENSTACK_SWIFT_FILTER + "region";
    public static final String OPENSTACK_SWIFT_DOMAIN = OPENSTACK_SWIFT_FILTER + "domain";
    public static final String OPENSTACK_SWIFT_TENANT_ID = OPENSTACK_SWIFT_FILTER + "tenantId";
    public static final String OPENSTACK_SWIFT_TOKEN_URL = OPENSTACK_SWIFT_FILTER + "token.url";
    public static final String OPENSTACK_SWIFT_IDENTITY_PROVIDER = OPENSTACK_SWIFT_FILTER + "identity.provider";
    public static final String OPENSTACK_SWIFT_CLIENT = OPENSTACK_SWIFT_FILTER + "client";
    public static final String OPENSTACK_SWIFT_CLIENT_SECRET = OPENSTACK_SWIFT_FILTER + "client.secret";
    public static final String OPENSTACK_SWIFT_USER_SECRET = OPENSTACK_SWIFT_FILTER + "user.secret";
}
