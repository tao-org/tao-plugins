#!/bin/bash
if [ "$#" == 2 ]; then
	while getopts "p:" arg; do
	  case ${arg} in
		p) param_file=${OPTARG};;
	  esac
	done
else
	while getopts "p:s:w:t:" arg; do
	  case ${arg} in
		p) source_s2=${OPTARG};;
		t) target=${OPTARG};;
		s) source_s3=${OPTARG};;
		w) static=${OPTARG};;
	  esac
	done
	
	fname="${source_s2##*/}"
	folder="$(dirname "${source_s2}")"
	y="${fname:11:4}"
	M="${fname:15:2}"
	D="${fname:17:2}"
	H="${fname:20:2}"
	m="${fname:22:2}"
	tile="${fname:39:5}"
	utc_date="${y}-${M}-${D} ${H}:${m}"
	start_time=${SECONDS}
	step_start=${SECONDS}
	echo "Processing scene $fname"
	echo "Extracting tile ${tile} information"
	era_file=${folder}/ERA5_${tile}_${y}${M}${D}.nc
	xmin=""
	ymin=""
	xmax=""
	ymax=""
	footprint=""
	OLD_IFS=${IFS}
	while read -r line
	do
		IFS=";"
		read -a arr <<<"$line"
		if [ "${arr[0]}" = "${tile}" ]
		then
			xmin=${arr[1]}
			ymin=${arr[2]}
			xmax=${arr[3]}
			ymax=${arr[4]}
			footprint=${arr[5]}
		fi
	done < /opt/senet/s2_tiles_boundaries.csv
	IFS=${OLD_IFS}
	echo "WKT is ${footprint}"
	dateStart=($(date -d "$y-$M-$D -1 days" +%Y-%m-%d))
	dateEnd=($(date -d "$y-$M-$D 11 days" +%Y-%m-%d))
	echo "Tile information completed in $(( SECONDS - step_start ))s"
	
	step_start=${SECONDS}
	echo "Step 1/15: Download ERA5 data"
	if [ ! -f "${era_file}" ]
	then
		echo "File ${era_file} was not found and will be downloaded"
		python3.6 /opt/senet/era5_download.py --area ${ymax}/${xmin}/${ymin}/${xmax} --start_date ${dateStart} --end_date ${dateEnd} --download_path ${era_file} --download_temperature true --download_dewpoint true --download_pressure true --download_wind_speed true --download_clear_sky_solar_radiation true --download_solar_radiation true --overwrite true
	else
		echo "File ${era_file} was already downloaded"
	fi
	echo "ERA5 download completed in $(( SECONDS - step_start ))s"
	
	step_start=${SECONDS}
	echo "Step 2/15: Sentinel-2 pre-processing"
	s2_pre_processing_paths=($(python3.6 /opt/senet/s2_graph_pre_processing.py ${source_s2} ${target} | tr -d "[''],"))
	biophy=${s2_pre_processing_paths[0]}
	s2_mask=${s2_pre_processing_paths[1]}
	reflectance=${s2_pre_processing_paths[2]}
	resample=${s2_pre_processing_paths[3]}
	zenit=${s2_pre_processing_paths[4]}
	echo "Interim products: ${biophy} ${s2_mask} ${reflectance} ${resample} ${zenit}"
	echo "Sentinel-2 pre-processing completed in $(( SECONDS - step_start ))s"
	
	step_start=${SECONDS}
	echo "Step 3/15: Elevation and landcover extraction"
	land_elevation=($(python3.6 /opt/senet/landcover_elevation.py ${resample} ${s2_mask} ${static} ${tile} ${target} | tr -d "[''],"))
	elevation=${land_elevation[0]}
	landcover=${land_elevation[1]}
	echo "Elevation and landcover extraction completed in $(( SECONDS - step_start ))s"
	
	step_start=${SECONDS}
	echo "Step 4/15: Sentinel-3 pre-processing"
	s3_pre_processing_paths=($(python3.6 /opt/senet/s3_graph_pre_processing.py ${source_s3} "${footprint}" ${target} | tr -d "[''],"))
	LST=${s3_pre_processing_paths[0]}
	s3_mask=${s3_pre_processing_paths[1]}
	obs_geo=${s3_pre_processing_paths[2]}
	echo "Sentinel-3 pre-processing completed in $(( SECONDS - step_start ))s"
	
	step_start=${SECONDS}
	echo "Step 5/15: Leaf spectra extraction"
	lfsp_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "LEAF_SPECTRA"))
	python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/leaf_spectra.py --biophysical_file ${biophy} --output_file ${lfsp_path}
	echo "Estimate leaf spectra completed in $(( SECONDS - step_start ))s"

	step_start=${SECONDS}
	echo "Step 6/15: Fraction of green vegetation extraction"
	fcgr_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "FRAC_GREEN"))
	python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/frac_green.py --sza_file ${zenit} --biophysical_file ${biophy} --min_frac_green 0.2 --output_file ${fcgr_path}
	echo "Estimate fraction of green vegetation completed in $(( SECONDS - step_start ))s"

	step_start=${SECONDS}
	echo "Step 7/15: Mapping structural parameters"
	slpms_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "STRUCTURAL"))
	python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/structural_params.py --landcover_map ${landcover} --lai_map ${biophy} --fgv_map ${fcgr_path} --landcover_band land_cover_CCILandCover-2015 --lookup_table /opt/sen-et-conda-Linux64/sen-et-snap-scripts/auxdata/LUT/ESA_CCI_LUT.csv --produce_vh true --produce_fc true --produce_chwr true --produce_lw true --produce_lid true --produce_igbp true --output_file ${slpms_path}
	echo "Maps of vegetation structural parameters completed in $(( SECONDS - step_start ))s"

	step_start=${SECONDS}
	echo "Step 8/15: Aerodynamic roughness estimation"
	ayro_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "AERO_ROUGHS"))
	python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/aerodynamic_roughness.py --lai_map ${biophy} --landcover_params_map ${slpms_path} --soil_roughness 0.01 --output_file ${ayro_path}
	echo "Estimate aerodynamic roughness completed in $(( SECONDS - step_start ))s"

	step_start=${SECONDS}
	echo "Step 9/15: Warping S3 to template"
	warp_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "WARP"))
	python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/warp_to_template.py --source ${obs_geo} --template ${reflectance} --resample_algorithm cubicspline --output ${warp_path}
	echo "Warp to template completed in $(( SECONDS - step_start ))s"

	step_start=${SECONDS}
	echo "Step 10/15: LST sharpening"
	sharpen_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "SHARPEN"))
	/bin/bash -c 'python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/data_mining_sharpener.py --sentinel_2_reflectance "$1" --sentinel_3_lst "$2" --high_res_dem $3 --high_res_geom "$4" --lst_quality_mask "$5" --date_time_utc "$6" --elevation_band elevation --lst_good_quality_flags 1 --cv_homogeneity_threshold 0.0 --moving_window_size 30 --parallel_jobs 1 --output "$7"' bash ${reflectance} ${LST} ${elevation} ${warp_path} ${s3_mask} "${utc_date}" ${sharpen_path}
	echo "LST sharpening completed in $(( SECONDS - step_start ))s"
	
	step_start=${SECONDS}
	echo "Step 11/15: ERA5 reanalysis data preparation"
	ecmwf5_data_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "EMCWF"))
	/bin/bash -c 'python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/ecmwf_data_preparation.py --elevation_map "$1" --elevation_band elevation --ecmwf_data_file "$2" --date_time_utc "$3" --time_zone 2 --prepare_temperature true --prepare_vapour_pressure true --prepare_air_pressure true --prepare_wind_speed true --prepare_clear_sky_solar_radiation true --prepare_daily_solar_irradiance true --output_file "$4"' bash ${elevation} ${era_file} "${utc_date}" ${ecmwf5_data_path}
	echo "Prepare ERA5 reanalysis data completed in $(( SECONDS - step_start ))s"

	step_start=${SECONDS}
	echo "Step 12/15: Longwave irradiation estimation"
	lwi_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "LONGWAVE_IRADIANCE"))
	python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/longwave_irradiance.py --meteo_product ${ecmwf5_data_path} --at_band air_temperature --vp_band vapour_pressure --ap_band air_pressure --at_height 100.0 --output_file ${lwi_path}
	echo "Longwave irradiance estimation completed in $(( SECONDS - step_start ))s"

	step_start=${SECONDS}
	echo "Step 13/15: Net shortwave radiation estimation"
	nsw_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "NET_SHORTWAVE"))
	python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/net_shortwave_radiation.py --lsp_product ${lfsp_path} --lai_product ${biophy} --csp_product ${slpms_path} --mi_product ${ecmwf5_data_path} --sza_product ${warp_path} --soil_ref_vis 0.15 --soil_ref_nir 0.25 --output_file ${nsw_path}
	echo "Net shortwave radiation estimation completed in $(( SECONDS - step_start ))s"

	step_start=${SECONDS}
	echo "Step 14/15: Land surface energy fluxes estimation"
	lef_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "ENEGY_FLUXES"))
	python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/energy_fluxes.py --lst ${sharpen_path} --lst_vza ${warp_path} --lai ${biophy} --csp ${slpms_path} --fgv ${fcgr_path} --ar ${ayro_path} --mi ${ecmwf5_data_path} --nsr ${nsw_path} --li ${lwi_path} --mask ${s2_mask} --soil_roughness 0.01 --alpha_pt 1.28 --atmospheric_measurement_height 100.0 --green_vegetation_emissivity 0.99 --soil_emissivity 0.97 --save_component_fluxes true --save_component_temperature true --save_aerodynamic_parameters true --output_file ${lef_path}
	echo "Land surface energy fluxes estimation completed in $(( SECONDS - step_start ))s"

	step_start=${SECONDS}
	echo "Step 15/15: Daily evapotranspiration estimation"
	dailyET_path=($(python3.6 -c "import sys;p=sys.argv[1].split('/');p[-1]=f'{sys.argv[2]}_{p[-1]}';print('/'.join(p))" ${target} "EVAPOTRANSPIRATION"))
	final_name=${dailyET_path/.dim/.tif}
	python3.6 /opt/sen-et-conda-Linux64/sen-et-snap-scripts/daily_evapotranspiration.py --ief_file ${lef_path} --mi_file ${ecmwf5_data_path} --output_file ${dailyET_path}
	/opt/snap/bin/gpt /opt/senet/convert.xml ${dailyET_path}
	echo "Daily evapotranspiration estimation completed in $(( SECONDS - step_start ))s"
	
	echo "Cleaning up"
	/bin/bash -c "mv $(dirname "${dailyET_path}")/evapotranspiration.tif $(dirname "${source_s2}")/$(basename "${final_name}")"
	rm -r /out/*
	echo "Done processing ${source_s2} in $(( SECONDS - start_time ))s"

fi
