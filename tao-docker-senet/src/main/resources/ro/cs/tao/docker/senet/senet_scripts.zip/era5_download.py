# -*- coding: utf-8 -*-
"""
Created on Tue Jul 17 14:47:50 2018

@author: rmgu
"""

import os
import click
import datetime
import cdsapi

@click.command()
@click.option('--area', required=False)
@click.option('--start_date', required=True)
@click.option('--end_date', required=True)
@click.option('--download_path', required=True, type=click.Path(file_okay=False))
@click.option('--download_temperature', required=True, type=click.BOOL)
@click.option('--download_dewpoint', required=True, type=click.BOOL)
@click.option('--download_pressure', required=True, type=click.BOOL)
@click.option('--download_wind_speed', required=True, type=click.BOOL)
@click.option('--download_clear_sky_solar_radiation', required=True, type=click.BOOL)
@click.option('--download_solar_radiation', required=True, type=click.BOOL)
@click.option('--overwrite', required=True, type=click.BOOL)
def main(area, start_date, end_date, download_path, download_pressure,
         download_temperature, download_dewpoint, download_wind_speed,
         download_clear_sky_solar_radiation, download_solar_radiation, overwrite):
	fields = []
	if download_temperature:
		fields.extend(['2m_temperature', 'z', '2m_dewpoint_temperature', 'surface_pressure'])
	if download_dewpoint and '2m_dewpoint_temperature' not in fields:
		fields.append('2m_dewpoint_temperature')
	if download_pressure and 'surface_pressure' not in fields:
		fields.append('surface_pressure')
	if download_wind_speed:
		fields.extend(['100m_v_component_of_wind', '100m_u_component_of_wind'])
	if download_clear_sky_solar_radiation:
		fields.append("surface_solar_radiation_downward_clear_sky")
	if download_solar_radiation:
		fields.append('surface_solar_radiation_downwards')
	if not os.path.isdir(os.path.expanduser('~')) and not os.getenv('CDSAPI_RC', None):
		os.environ['CDSAPI_RC'] = os.path.join(cur_path, '..\\..\\..\\..\\.cdsapirc')

	s = {}

	s["variable"] = fields
	s["product_type"] = "reanalysis"
	s["date"] = start_date+"/"+end_date
	s["time"] = [str(t).zfill(2)+":00" for t in range(0, 24, 1)]
	if area:
		s["area"] = area
	s["format"] = "netcdf"

	# Connect to the server and download the data
	if not os.path.exists(download_path) or overwrite:
		c = cdsapi.Client()
		c.retrieve("reanalysis-era5-single-levels", s, download_path)
	print("Downloaded")
        
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("ERROR:" + str(e))
