import sys
import subprocess
import multiprocessing

REPROJECT_SCRIPT = "/opt/senet/s3_pre_processing_scripts/reproject.xml"
LST_SCRIPT = "/opt/senet/s3_pre_processing_scripts/LST.xml"
OBS_GEOM_SCRIPT = "/opt/senet/s3_pre_processing_scripts/observation_geometry.xml"
MASK_SCRIPT = "/opt/senet/s3_pre_processing_scripts/mask.xml"


def rename_output(input_path, name_apx) -> str:
    """
        This function append a tag to a file in a path-like string
        /data/some_folder/some_file.txt -> /data/some_folder/TAG_some_file.txt
    """
    temp = input_path.split("/")
    temp[-1] = f"{name_apx}_{temp[-1]}"
    return "/".join(temp)
    

def sentinel_3_pre_processing(**kwargs: "source_path, s2_footprint, target_path") -> None:
    reproject_path = rename_output(kwargs["target_path"], "S3_REPROJECT")
    s2_footprint = "-PgeoRegion=" + kwargs["s2_footprint"]
    reproject_subset_cmd = ["/opt/snap/bin/gpt", REPROJECT_SCRIPT, kwargs["source_path"], s2_footprint, "-t", reproject_path]
    reproject_subset_process = subprocess.run(reproject_subset_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output_products_paths = multiprocessing.Manager().dict()
    output_products_paths["REPROJECT"] = reproject_path

    mask_thread = multiprocessing.Process(target=mask, args=[reproject_path, kwargs["target_path"], output_products_paths])
    LST_thread = multiprocessing.Process(target=LST, args=[reproject_path, kwargs["target_path"], output_products_paths])
    obs_geo_thread = multiprocessing.Process(target=observation_geometry, args=[reproject_path, kwargs["target_path"], output_products_paths])
    active_threads = [mask_thread, LST_thread, obs_geo_thread]
    [thread.start() for thread in active_threads]
    [thread.join() for thread in active_threads]
    print(list(sorted(output_products_paths.values())))

def mask(source, target, process_handler):
    mask_target = rename_output(target, "S3_MASK")
    mask_cmd = ["/opt/snap/bin/gpt", MASK_SCRIPT, source, "-t", mask_target]
    mask_process = subprocess.run(mask_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if mask_process.returncode != 0:
        print(f'{mask_process.stdout.decode()} {mask_process.stderr.decode()}')
    process_handler["MASK"] = mask_target

def LST(source, target, process_handler):
    lst_target = rename_output(target, "S3_LST")
    lst_cmd = ["/opt/snap/bin/gpt", LST_SCRIPT, source, "-t", lst_target]
    lst_process = subprocess.run(lst_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if lst_process.returncode != 0:
        print(f'{lst_process.stdout.decode()} {lst_process.stderr.decode()}')
    process_handler["LST"] = lst_target

def observation_geometry(source, target, process_handler):
    obs_geo_target = rename_output(target, "S3_OBS_GEO")
    obs_geo_cmd = ["/opt/snap/bin/gpt", OBS_GEOM_SCRIPT, source, "-t", obs_geo_target]
    obs_geo_process = subprocess.run(obs_geo_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if obs_geo_process.returncode != 0:
        print(f'{obs_geo_process.stdout.decode()} {obs_geo_process.stderr.decode()}')
    process_handler["OBG"] = obs_geo_target
 

if __name__ == "__main__":
    # Recover script parameters using sys.argv array
    source, footprint, target = sys.argv[1:]
    sentinel_3_pre_processing(source_path=source, s2_footprint=footprint, target_path=target)