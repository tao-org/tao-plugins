import sys
import subprocess
import multiprocessing

# ut
from time import perf_counter

# S2
RESAMPLE_SCRIPT = "/opt/senet/s2_pre_processing_scripts/resample.xml"
REFLECTANCE_SCRIPT = "/opt/senet/s2_pre_processing_scripts/reflectance.xml"
SUN_ZENIT_SCRIPT = "/opt/senet/s2_pre_processing_scripts/zenit.xml"
BANDMATH_MASK_SCRIPT = "/opt/senet/s2_pre_processing_scripts/mask.xml"
BIOPHYSICAL_SCRIPT = "/opt/senet/s2_pre_processing_scripts/biophysical.xml"


def rename_output(input_path, name_apx) -> str:
    """
        This function append a tag to a file in a path-like string
        /data/some_folder/some_file.txt -> /data/some_folder/TAG_some_file.txt
    """
    temp = input_path.split("/")
    temp[-1] = f"{name_apx}_{temp[-1]}"
    return "/".join(temp)


def sentinel_2_pre_processing(**kwargs: "source_path, target_path") -> None:
    # Output path of resample and subset is renamed from /path/to/out.dim to /path/to/RESAMPLE_out.dim to avoid overwrite
    resample_path = rename_output(kwargs["target_path"], "S2_RESAMPLE")
    # Run resample + subset
    resample_subset_cmd = ["/opt/snap/bin/gpt", "-c", "256M", RESAMPLE_SCRIPT, kwargs["source_path"], "-t", resample_path]
    output_products_paths = multiprocessing.Manager().dict()
    output_products_paths["RESAMPLE"] = resample_path
    resample_subset_process = subprocess.run(resample_subset_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    reflectance_thread = multiprocessing.Process(target=reflectance, args=[resample_path, kwargs["target_path"], output_products_paths])
    zenit_thread = multiprocessing.Process(target=zenit, args=[resample_path, kwargs["target_path"], output_products_paths])
    mask_thread = multiprocessing.Process(target=mask, args=[resample_path, kwargs["target_path"], output_products_paths])
    biophy_thread = multiprocessing.Process(target=biophy, args=[resample_path, kwargs["target_path"], output_products_paths])
    active_threads = [reflectance_thread, zenit_thread, mask_thread, biophy_thread]
    [thread.start() for thread in active_threads]
    [thread.join() for thread in active_threads]
    print(list(sorted(output_products_paths.values())))


def reflectance(source, target, process_handler):
    # Rename output product to avoid overwrite
    reflectance_target = rename_output(target, "S2_REFLECTANCE")
    # Create subprocess command, and time execution
    reflectance_cmd = ["/opt/snap/bin/gpt", "-c", "256M", REFLECTANCE_SCRIPT, source, "-t", reflectance_target]
    reflectance_process = subprocess.run(reflectance_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # Capture output if process status is other than sucessfull
    # @ToDo logging
    if reflectance_process.returncode != 0:
        print(reflectance_process.stdout.decode())
        print(reflectance_process.stderr.decode())
    process_handler["REFLECTANCE"] = reflectance_target


def mask(source, target, process_handler):
    mask_target = rename_output(target, "S2_MASK")
    mask_cmd = ["/opt/snap/bin/gpt", "-c", "256M", BANDMATH_MASK_SCRIPT, source, "-t", mask_target]
    mask_process = subprocess.run(mask_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if mask_process.returncode != 0:
        print(f'{mask_process.stdout.decode()} {mask_process.stderr.decode()}')
    process_handler["MASK"] = mask_target


def zenit(source, target, process_handler):
    zenit_target = rename_output(target, "S2_ZENIT")
    zenit_cmd = ["/opt/snap/bin/gpt", "-c", "256M", SUN_ZENIT_SCRIPT, source, "-t", zenit_target]
    zenit_process = subprocess.run(zenit_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if zenit_process.returncode != 0:
        print(f'{zenit_process.stdout.decode()} {zenit_process.stderr.decode()}')
    process_handler["ZENIT"] = zenit_target


def biophy(source, target, process_handler):
    biophy_target = rename_output(target, "S2_BIOPHYSICAL")
    biophy_cmd = ["/opt/snap/bin/gpt", "-c", "256M", BIOPHYSICAL_SCRIPT, source, "-t", biophy_target]
    timer_start = perf_counter()
    biophy_process = subprocess.run(biophy_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    timer_stop = perf_counter()
    if biophy_process.returncode != 0:
        print(f'{biophy_process.stdout.decode()} {biophy_process.stderr.decode()}')
    process_handler["BIOPHY"] = biophy_target
    

if __name__ == "__main__":
    # Recover script parameters using sys.argv array
    source, target = sys.argv[1:]
    
    sentinel_2_pre_processing(source_path=source, target_path=target)