import sys
import os.path
import subprocess
import multiprocessing

ELEVATION_SCRIPT = "/opt/senet/add_elevation.xml"
LANDCOVER_SCRIPT = "/opt/senet/add_landcover.xml"


def rename_output(input_path, name_apx) -> str:
    """
        This function append a tag to a file in a path-like string
        /data/some_folder/some_file.txt -> /data/some_folder/TAG_some_file.txt
    """
    temp = input_path.split("/")
    temp[-1] = f"{name_apx}_{temp[-1]}"
    return "/".join(temp)


def add_landcover(source, target, process_handler):
    landcover_cmd = ["/opt/snap/bin/gpt", LANDCOVER_SCRIPT, source, "-t", target]
    landcover_process = subprocess.run(landcover_cmd, stdout=subprocess.PIPE, stderr = subprocess.PIPE)
    if landcover_process.returncode != 0:
        print(f'{landcover_process.stdout.decode()} {landcover_process.stderr.decode()}')
    process_handler["LANDCOVER"] = target
       
    
def add_elevation(source, target, process_handler):
    elevation_cmd = ["/opt/snap/bin/gpt", ELEVATION_SCRIPT, source, "-t", target]
    elevation_process = subprocess.run(elevation_cmd, stdout=subprocess.PIPE, stderr = subprocess.PIPE)
    if elevation_process.returncode != 0:
        print(f'{elevation_process.stdout.decode()} {elevation_process.stderr.decode()}')
    process_handler["ELEVATON"] = target
    
if __name__ == "__main__":
    resample, mask, static, tile, target = sys.argv[1:]
    output_products_paths = multiprocessing.Manager().dict()
    
    landcover_target = static + "LANDCOVER_" + tile + ".dim"
    elevation_target = static + "ELEVATION_" + tile + ".dim"
    
    if not(os.path.exists(landcover_target) and os.path.exists(elevation_target)):
        elevation_thread = multiprocessing.Process(target=add_elevation, args=[resample, elevation_target, output_products_paths])
        landcover_thread = multiprocessing.Process(target=add_landcover, args=[mask, landcover_target, output_products_paths])
        [thread.start() for thread in [elevation_thread, landcover_thread]]
        [thread.join() for thread in [elevation_thread, landcover_thread]]
    else:
        output_products_paths["ELEVATON"] = elevation_target
        output_products_paths["LANDCOVER"] = landcover_target

    print(list(sorted(output_products_paths.values())))